import { users, squawkCodes, type User, type InsertUser, type SquawkCode, type InsertSquawkCode } from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createSquawkCode(squawkCode: InsertSquawkCode): Promise<SquawkCode>;
  getActiveSquawkCodes(): Promise<SquawkCode[]>;
  expireOldCodes(): Promise<void>;
  clearAllCodes(): Promise<void>;
  getUsedCodes(): Promise<string[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const { db } = await import("./db");
    const { eq } = await import("drizzle-orm");
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const { db } = await import("./db");
    const { eq } = await import("drizzle-orm");
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const { db } = await import("./db");
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async createSquawkCode(insertSquawkCode: InsertSquawkCode): Promise<SquawkCode> {
    const { db } = await import("./db");
    const [squawkCode] = await db
      .insert(squawkCodes)
      .values(insertSquawkCode)
      .returning();
    return squawkCode;
  }

  async getActiveSquawkCodes(): Promise<SquawkCode[]> {
    const { db } = await import("./db");
    const { desc, and, eq, gt } = await import("drizzle-orm");
    const codes = await db
      .select()
      .from(squawkCodes)
      .where(and(
        eq(squawkCodes.isActive, true),
        gt(squawkCodes.expiresAt, new Date())
      ))
      .orderBy(desc(squawkCodes.generatedAt));
    return codes;
  }

  async expireOldCodes(): Promise<void> {
    const { db } = await import("./db");
    const { lt, eq, and } = await import("drizzle-orm");
    await db
      .update(squawkCodes)
      .set({ isActive: false })
      .where(and(
        eq(squawkCodes.isActive, true),
        lt(squawkCodes.expiresAt, new Date())
      ));
  }

  async clearAllCodes(): Promise<void> {
    const { db } = await import("./db");
    const { eq } = await import("drizzle-orm");
    await db
      .update(squawkCodes)
      .set({ isActive: false })
      .where(eq(squawkCodes.isActive, true));
  }

  async getUsedCodes(): Promise<string[]> {
    const { db } = await import("./db");
    const { and, eq, gt } = await import("drizzle-orm");
    const codes = await db
      .select({ code: squawkCodes.code })
      .from(squawkCodes)
      .where(and(
        eq(squawkCodes.isActive, true),
        gt(squawkCodes.expiresAt, new Date())
      ));
    return codes.map(c => c.code);
  }
}

export const storage = new DatabaseStorage();

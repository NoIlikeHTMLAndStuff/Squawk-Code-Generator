import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { storage } from "./storage";

const EMERGENCY_CODES = ['7500', '7600', '7700'];

export async function registerRoutes(app: Express): Promise<Server> {
  // Read-only mode check
  const isReadOnly = process.env.READ_ONLY_MODE === 'true';

  // Generate squawk code endpoint
  app.get("/api/squawk/generate", async (req, res) => {
    if (isReadOnly) {
      return res.status(403).json({ error: "Generator is in read-only mode" });
    }
    
    try {
      // First expire old codes
      await storage.expireOldCodes();
      
      // Get currently used codes
      const usedCodes = await storage.getUsedCodes();
      
      let code: string;
      let attempts = 0;
      const maxAttempts = 100;
      
      do {
        // Generate 4-digit code using only 0-7 (octal)
        code = '';
        for (let i = 0; i < 4; i++) {
          code += Math.floor(Math.random() * 8);
        }
        attempts++;
        
        if (attempts > maxAttempts) {
          return res.status(500).json({ error: "Unable to generate unique code" });
        }
      } while (EMERGENCY_CODES.includes(code) || usedCodes.includes(code));
      
      // Set expiry time to 10 minutes from now
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000);
      
      // Save to database
      await storage.createSquawkCode({ code, expiresAt });
      
      res.json({ 
        code,
        timestamp: new Date().toISOString(),
        expiresAt: expiresAt.toISOString(),
        excluded: EMERGENCY_CODES
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to generate squawk code" });
    }
  });

  // Get active squawk codes history
  app.get("/api/squawk/history", async (req, res) => {
    try {
      // First expire old codes
      await storage.expireOldCodes();
      
      const codes = await storage.getActiveSquawkCodes();
      res.json({ codes });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch squawk code history" });
    }
  });

  // Clear all active codes
  app.post("/api/squawk/clear", async (req, res) => {
    if (isReadOnly) {
      return res.status(403).json({ error: "Clear function is disabled in read-only mode" });
    }
    
    try {
      await storage.clearAllCodes();
      res.json({ message: "All codes cleared successfully" });
    } catch (error) {
      res.status(500).json({ error: "Failed to clear codes" });
    }
  });

  // Get emergency codes info
  app.get("/api/squawk/emergency-codes", async (req, res) => {
    try {
      const emergencyCodes = {
        '7500': 'Hijacking',
        '7600': 'Radio Failure',
        '7700': 'General Emergency'
      };
      
      res.json({ emergencyCodes });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch emergency codes" });
    }
  });

  // Validate squawk code endpoint
  app.post("/api/squawk/validate", async (req, res) => {
    try {
      const { code } = req.body;
      
      if (!code || typeof code !== 'string') {
        return res.status(400).json({ error: "Code is required and must be a string" });
      }
      
      if (code.length !== 4) {
        return res.status(400).json({ 
          valid: false, 
          error: "Code must be exactly 4 digits" 
        });
      }
      
      // Check if all digits are 0-7
      const isValidDigits = /^[0-7]{4}$/.test(code);
      if (!isValidDigits) {
        return res.status(400).json({ 
          valid: false, 
          error: "Code must contain only digits 0-7" 
        });
      }
      
      // Check if it's an emergency code
      const isEmergencyCode = EMERGENCY_CODES.includes(code);
      
      res.json({ 
        valid: !isEmergencyCode,
        code,
        isEmergencyCode,
        message: isEmergencyCode ? `${code} is an emergency code` : `${code} is a valid squawk code`
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to validate squawk code" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Plane, 
  Shuffle, 
  Shield, 
  CheckCircle, 
  Info, 
  AlertTriangle, 
  Copy, 
  History, 
  Trash2, 
  Clock,
  Loader2
} from "lucide-react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";
import { ThemeToggle } from "@/components/theme-toggle";
import { ProtectedCredits } from "@/components/protected-credits";

const EMERGENCY_CODES = ['7500', '7600', '7700'];

const EMERGENCY_CODE_INFO = {
  '7500': 'Hijacking',
  '7600': 'Radio Failure', 
  '7700': 'General Emergency'
};

// Utility function to format time remaining
function formatTimeRemaining(expiresAt: string): string {
  const expiry = new Date(expiresAt);
  const now = new Date();
  const diff = expiry.getTime() - now.getTime();
  
  if (diff <= 0) return "Expired";
  
  const minutes = Math.floor(diff / (1000 * 60));
  const seconds = Math.floor((diff % (1000 * 60)) / 1000);
  
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

// Utility function to format fluid time remaining (from milliseconds)
function formatFluidTimeRemaining(remainingMs: number): string {
  if (remainingMs <= 0) {
    return "Expired";
  }
  
  const minutes = Math.floor(remainingMs / (1000 * 60));
  const seconds = Math.floor((remainingMs % (1000 * 60)) / 1000);
  
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

// Utility function to copy to clipboard
async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (err) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    document.body.appendChild(textArea);
    textArea.select();
    document.execCommand('copy');
    document.body.removeChild(textArea);
    return true;
  }
}

export default function SquawkGenerator() {
  const [currentCode, setCurrentCode] = useState<string>('----');
  const [codeStatus, setCodeStatus] = useState<string>('Ready to generate');
  const [activeTab, setActiveTab] = useState<string>('generator');
  const [fluidTimers, setFluidTimers] = useState<{ [key: string]: number }>({});
  const { toast } = useToast();

  // Query to get squawk code history with auto-refresh
  const { data: historyData, isLoading: historyLoading } = useQuery({
    queryKey: ['/api/squawk/history'],
    refetchInterval: 1000,
    staleTime: 0,
  });

  // Mutation to generate new squawk code
  const generateMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('GET', '/api/squawk/generate');
      return await res.json();
    },
    onSuccess: (data: any) => {
      setCurrentCode(data.code);
      setCodeStatus(`Valid code generated • ${new Date().toLocaleTimeString()}`);
      toast({
        title: "Code Generated",
        description: `Generated squawk code: ${data.code}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/squawk/history'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to generate squawk code",
        variant: "destructive",
      });
    }
  });

  // Mutation to clear all codes
  const clearMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/squawk/clear');
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Codes Cleared",
        description: "All active codes have been cleared",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/squawk/history'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to clear codes",
        variant: "destructive",
      });
    }
  });

  // Reset current code when history becomes empty (but not during generation)
  useEffect(() => {
    const codes = (historyData as any)?.codes || [];
    // Only reset if there are no codes AND we're not generating AND we haven't just generated
    // Use a small delay to prevent interfering with fresh generation
    if (codes.length === 0 && currentCode !== '----' && !generateMutation.isPending) {
      const timeoutId = setTimeout(() => {
        // Double-check conditions after delay
        if (!generateMutation.isPending && (historyData as any)?.codes?.length === 0) {
          setCurrentCode('----');
          setCodeStatus('Ready to generate');
        }
      }, 500); // Small delay to avoid race conditions
      
      return () => clearTimeout(timeoutId);
    }
  }, [historyData, currentCode, generateMutation.isPending]);

  // Fluid timer effect for smooth countdown animation
  useEffect(() => {
    const codes = (historyData as any)?.codes || [];
    if (codes.length === 0) {
      setFluidTimers({});
      return;
    }

    const interval = setInterval(() => {
      const now = Date.now();
      const newTimers: { [key: string]: number } = {};
      
      codes.forEach((codeData: any) => {
        const expiresAt = new Date(codeData.expiresAt).getTime();
        const remaining = Math.max(0, expiresAt - now);
        newTimers[codeData.id] = remaining;
      });
      
      setFluidTimers(newTimers);
    }, 100); // Update every 100ms for smooth animation

    return () => clearInterval(interval);
  }, [historyData]);

  // Copy to clipboard function
  const handleCopyCode = async (code: string) => {
    const success = await copyToClipboard(code);
    if (success) {
      toast({
        title: "Copied!",
        description: `Code ${code} copied to clipboard`,
      });
    } else {
      toast({
        title: "Copy Failed",
        description: "Unable to copy code to clipboard",
        variant: "destructive",
      });
    }
  };

  const generateSquawkCode = () => {
    generateMutation.mutate();
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card shadow-sm border-b border-border">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <motion.div 
                className="bg-blue-600 p-2 rounded-lg"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Plane className="text-white h-6 w-6" />
              </motion.div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Squawk Code Generator</h1>
                <p className="text-muted-foreground text-sm">Professional Aviation Transponder Codes</p>
              </div>
            </div>
            <ThemeToggle />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8 transition-all duration-300">
            <TabsTrigger value="generator" className="flex items-center gap-2 transition-all duration-300">
              <Shuffle className="h-4 w-4" />
              Generator
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2 transition-all duration-300">
              <History className="h-4 w-4" />
              Active Codes
            </TabsTrigger>
            <TabsTrigger value="info" className="flex items-center gap-2 transition-all duration-300">
              <Info className="h-4 w-4" />
              Information
            </TabsTrigger>
          </TabsList>

          {/* Generator Tab */}
          <TabsContent value="generator" className="space-y-6">
            <motion.div
              key="generator-content"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4, ease: "easeInOut" }}
            >
              <Card className="rounded-2xl shadow-lg border-border">
                <CardContent className="p-8">
                  <div className="text-center mb-8">
                    <h2 className="text-3xl font-bold text-foreground mb-2">Generate Squawk Code</h2>
                    <p className="text-muted-foreground">Click the button below to generate a valid 4-digit transponder code</p>
                  </div>

                  {/* Code Display */}
                  <motion.div 
                    className="bg-slate-900 dark:bg-slate-800 rounded-xl p-8 mb-8 text-center"
                    whileHover={{ scale: 1.02 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <div className="mb-3">
                      <span className="text-slate-400 text-sm font-medium uppercase tracking-wide">Generated Code</span>
                    </div>
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={currentCode}
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.8, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className={`text-6xl font-mono font-bold text-green-400 tracking-wider mb-2 ${generateMutation.isPending ? 'animate-pulse' : ''} ${currentCode !== '----' ? 'code-glow' : ''}`}
                      >
                        {currentCode}
                      </motion.div>
                    </AnimatePresence>
                    <div className="text-slate-400 text-sm">
                      {codeStatus}
                    </div>
                    {currentCode !== '----' && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="mt-4"
                      >
                        <Button
                          onClick={() => handleCopyCode(currentCode)}
                          variant="outline"
                          size="sm"
                          className="text-slate-400 hover:text-white"
                        >
                          <Copy className="h-4 w-4 mr-2" />
                          Copy Code
                        </Button>
                      </motion.div>
                    )}
                  </motion.div>

                  {/* Generate Button */}
                  <div className="text-center mb-6">
                    <motion.div
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Button
                        onClick={generateSquawkCode}
                        disabled={generateMutation.isPending}
                        className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 px-8 rounded-xl transition-all duration-200 hover:shadow-lg focus:outline-none focus:ring-4 focus:ring-blue-500/30 disabled:opacity-50 disabled:cursor-not-allowed"
                        size="lg"
                      >
                        {generateMutation.isPending ? (
                          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        ) : (
                          <Shuffle className="mr-2 h-5 w-5" />
                        )}
                        {generateMutation.isPending ? 'Generating...' : 'Generate New Code'}
                      </Button>
                    </motion.div>
                    
                    {/* Clear All Button */}
                    {(historyData as any)?.codes?.length > 0 && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="mt-4"
                      >
                        <Button
                          onClick={() => clearMutation.mutate()}
                          disabled={clearMutation.isPending}
                          variant="outline"
                          className="text-red-600 hover:text-red-700 border-red-200 hover:border-red-300 hover:bg-red-50 dark:hover:bg-red-950/20"
                        >
                          {clearMutation.isPending ? (
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          ) : (
                            <Trash2 className="mr-2 h-4 w-4" />
                          )}
                          {clearMutation.isPending ? 'Clearing...' : 'Clear All Codes'}
                        </Button>
                      </motion.div>
                    )}
                  </div>

                  {/* Generation Stats */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                    <motion.div 
                      className="bg-secondary/50 rounded-lg p-4"
                      whileHover={{ scale: 1.05 }}
                    >
                      <div className="text-2xl font-bold text-foreground">{(historyData as any)?.codes?.length || 0}</div>
                      <div className="text-muted-foreground text-sm">Active Codes</div>
                    </motion.div>
                    <motion.div 
                      className="bg-secondary/50 rounded-lg p-4"
                      whileHover={{ scale: 1.05 }}
                    >
                      <div className="text-2xl font-bold text-green-600">
                        <CheckCircle className="h-8 w-8 mx-auto" />
                      </div>
                      <div className="text-muted-foreground text-sm">Emergency Codes Excluded</div>
                    </motion.div>
                    <motion.div 
                      className="bg-secondary/50 rounded-lg p-4"
                      whileHover={{ scale: 1.05 }}
                    >
                      <div className="text-2xl font-bold text-foreground">0-7</div>
                      <div className="text-muted-foreground text-sm">Valid Digit Range</div>
                    </motion.div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history" className="space-y-6">
            <motion.div
              key="history-content"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4, ease: "easeInOut" }}
            >
              <Card className="rounded-2xl shadow-lg border-border">
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle className="flex items-center gap-2">
                      <History className="h-5 w-5" />
                      Active Squawk Codes
                    </CardTitle>
                    <Button
                      onClick={() => clearMutation.mutate()}
                      disabled={clearMutation.isPending}
                      variant="destructive"
                      size="sm"
                      className="flex items-center gap-2"
                    >
                      {clearMutation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Trash2 className="h-4 w-4" />
                      )}
                      Clear All
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {historyLoading ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                    </div>
                  ) : (historyData as any)?.codes?.length > 0 ? (
                    <div className="space-y-3">
                      {(historyData as any).codes.map((codeData: any, index: number) => (
                        <motion.div
                          key={codeData.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.1 }}
                          className="flex items-center justify-between p-4 bg-secondary/30 rounded-lg border border-border hover:bg-secondary/50 transition-colors"
                        >
                          <div className="flex items-center gap-4">
                            <div className="font-mono text-2xl font-bold text-foreground">
                              {codeData.code}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              Generated: {new Date(codeData.generatedAt).toLocaleTimeString()}
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className="flex items-center gap-2 text-sm">
                              <Clock className="h-4 w-4 text-orange-500" />
                              <span className="font-mono text-orange-500">
                                {fluidTimers[codeData.id] !== undefined 
                                  ? formatFluidTimeRemaining(fluidTimers[codeData.id])
                                  : formatTimeRemaining(codeData.expiresAt)
                                }
                              </span>
                            </div>
                            <Button
                              onClick={() => handleCopyCode(codeData.code)}
                              variant="outline"
                              size="sm"
                              className="flex items-center gap-2"
                            >
                              <Copy className="h-4 w-4" />
                              Copy
                            </Button>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <History className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No active codes found</p>
                      <p className="text-sm">Generate a code to get started</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Information Tab */}
          <TabsContent value="info" className="space-y-6">
            <motion.div
              key="info-content"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4, ease: "easeInOut" }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-6"
            >
              {/* About Squawk Codes */}
              <Card className="rounded-xl shadow-sm border-border">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="bg-blue-100 dark:bg-blue-900 p-2 rounded-lg mr-3">
                      <Info className="text-blue-600 dark:text-blue-400 h-5 w-5" />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground">About Squawk Codes</h3>
                  </div>
                  <div className="space-y-3 text-muted-foreground">
                    <p>Squawk codes are 4-digit transponder codes used in aviation to identify aircraft on radar systems.</p>
                    <p>Valid codes use only digits 0-7 (octal system) and serve various purposes from routine identification to emergency declarations.</p>
                    <p>This generator ensures all codes follow proper aviation standards and excludes restricted emergency codes.</p>
                    <div className="mt-4 p-3 bg-secondary/50 rounded-lg">
                      <p className="text-sm font-medium text-foreground">Code Expiry: 10 minutes</p>
                      <p className="text-sm">All generated codes automatically expire after 10 minutes to prevent conflicts.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Excluded Emergency Codes */}
              <Card className="rounded-xl shadow-sm border-border">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="bg-red-100 dark:bg-red-900 p-2 rounded-lg mr-3">
                      <AlertTriangle className="text-red-600 dark:text-red-400 h-5 w-5" />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground">Excluded Emergency Codes</h3>
                  </div>
                  <div className="space-y-3">
                    {EMERGENCY_CODES.map((code) => (
                      <div key={code} className="flex items-center justify-between p-3 bg-red-50 dark:bg-red-950 rounded-lg">
                        <span className="font-mono font-semibold text-red-700 dark:text-red-400">{code}</span>
                        <Badge variant="destructive" className="text-red-600 bg-red-100 dark:bg-red-900">
                          {EMERGENCY_CODE_INFO[code as keyof typeof EMERGENCY_CODE_INFO]}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Credits */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card className="rounded-xl shadow-sm border-border">
                <CardContent className="p-6">
                  <div className="text-center">
                    <h3 className="text-xl font-semibold text-foreground mb-4">About This Tool</h3>
                    <p className="text-muted-foreground mb-4">
                      Created by <span className="font-semibold text-foreground">isandstuff</span> for aviation training and simulation use.
                    </p>
                    <p className="text-xs text-muted-foreground/70 mb-4">
                      © 2025 isandstuff - All rights reserved. Attribution must be preserved.
                    </p>
                    <p className="text-muted-foreground text-sm">
                      This generator is designed for educational purposes, flight simulation, and training scenarios.
                      All codes are compliant with aviation standards and exclude emergency transponder codes.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-16">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <ProtectedCredits />
        </div>
      </footer>
    </div>
  );
}
import { Plane } from "lucide-react";

/**
 * Protected Credits Component
 * 
 * This component contains attribution information that should not be modified.
 * The credits are embedded in a way that makes them difficult to change accidentally.
 * 
 * @copyright 2025 isandstuff - All rights reserved
 * @license This attribution must remain intact in all versions
 */

// Protected creator information - DO NOT MODIFY
const CREATOR_INFO = Object.freeze({
  name: "isandstuff",
  year: "2025",
  purpose: "aviation training and simulation",
  protected: true
});

// Obfuscated credit validation
const validateCredits = () => {
  const expectedCreator = ["i", "s", "a", "n", "d", "s", "t", "u", "f", "f"].join("");
  return CREATOR_INFO.name === expectedCreator && CREATOR_INFO.protected;
};

export function ProtectedCredits() {
  // Verify credits integrity
  if (!validateCredits()) {
    console.warn("Credits validation failed - original attribution must be preserved");
  }

  return (
    <div className="text-center text-muted-foreground">
      <p className="text-sm">
        <Plane className="inline-block mr-1 h-4 w-4" />
        Professional Aviation Tools • For Training and Educational Use
      </p>
      <p className="text-xs mt-1 opacity-70">
        Made by <span className="font-semibold text-foreground">{CREATOR_INFO.name}</span> © {CREATOR_INFO.year}
      </p>
    </div>
  );
}

// Additional protection layer
export default ProtectedCredits;